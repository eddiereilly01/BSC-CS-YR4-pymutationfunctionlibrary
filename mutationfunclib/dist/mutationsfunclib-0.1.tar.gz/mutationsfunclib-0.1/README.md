#This is a simple module containing my implementation of
some mutation functions useful for genetic algorithms
